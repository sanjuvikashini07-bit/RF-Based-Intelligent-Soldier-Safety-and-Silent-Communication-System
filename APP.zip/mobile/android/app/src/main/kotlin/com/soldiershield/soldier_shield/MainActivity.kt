package com.soldiershield.soldier_shield

import io.flutter.embedding.android.FlutterFragmentActivity

// FlutterFragmentActivity (not FlutterActivity) is required by the
// local_auth plugin's biometric prompt.
class MainActivity : FlutterFragmentActivity()
