import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/alert_item.dart';
import '../models/enums.dart';
import '../services/mock_data_service.dart';

final alertsStreamProvider = StreamProvider<List<AlertItem>>((ref) {
  final service = MockDataService.instance;
  return service.alertsStream.map((_) => service.alerts);
});

final alertsProvider = Provider<List<AlertItem>>((ref) {
  final async = ref.watch(alertsStreamProvider);
  return async.maybeWhen(
    data: (data) => data,
    orElse: () => MockDataService.instance.alerts,
  );
});

final activeAlertsProvider = Provider<List<AlertItem>>((ref) {
  return ref.watch(alertsProvider).where((a) => a.status != AlertStatus.resolved).toList();
});

final emergencyAlertProvider = StreamProvider<AlertItem>((ref) {
  return MockDataService.instance.emergencyStream;
});

class AlertActions {
  void acknowledge(String alertId, String operator) {
    MockDataService.instance.acknowledgeAlert(alertId, operator);
  }

  AlertItem trigger(String soldierId, String messageCode) {
    return MockDataService.instance.triggerMessage(soldierId, messageCode);
  }
}

final alertActionsProvider = Provider((ref) => AlertActions());
