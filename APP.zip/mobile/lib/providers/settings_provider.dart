import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/storage_service.dart';

class AppSettingsState {
  final bool notificationsEnabled;
  final bool alarmSoundEnabled;
  final bool vibrationEnabled;
  final String language;

  const AppSettingsState({
    this.notificationsEnabled = true,
    this.alarmSoundEnabled = true,
    this.vibrationEnabled = true,
    this.language = 'English',
  });

  AppSettingsState copyWith({
    bool? notificationsEnabled,
    bool? alarmSoundEnabled,
    bool? vibrationEnabled,
    String? language,
  }) {
    return AppSettingsState(
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
      alarmSoundEnabled: alarmSoundEnabled ?? this.alarmSoundEnabled,
      vibrationEnabled: vibrationEnabled ?? this.vibrationEnabled,
      language: language ?? this.language,
    );
  }
}

class SettingsNotifier extends StateNotifier<AppSettingsState> {
  SettingsNotifier() : super(_load());

  static AppSettingsState _load() {
    final storage = StorageService.instance;
    return AppSettingsState(
      notificationsEnabled: storage.getSetting('notificationsEnabled', defaultValue: true) ?? true,
      alarmSoundEnabled: storage.getSetting('alarmSoundEnabled', defaultValue: true) ?? true,
      vibrationEnabled: storage.getSetting('vibrationEnabled', defaultValue: true) ?? true,
      language: storage.getSetting('language', defaultValue: 'English') ?? 'English',
    );
  }

  void toggleNotifications(bool value) {
    state = state.copyWith(notificationsEnabled: value);
    StorageService.instance.setSetting('notificationsEnabled', value);
  }

  void toggleAlarm(bool value) {
    state = state.copyWith(alarmSoundEnabled: value);
    StorageService.instance.setSetting('alarmSoundEnabled', value);
  }

  void toggleVibration(bool value) {
    state = state.copyWith(vibrationEnabled: value);
    StorageService.instance.setSetting('vibrationEnabled', value);
  }

  void setLanguage(String value) {
    state = state.copyWith(language: value);
    StorageService.instance.setSetting('language', value);
  }
}

final settingsProvider = StateNotifierProvider<SettingsNotifier, AppSettingsState>((ref) {
  return SettingsNotifier();
});
