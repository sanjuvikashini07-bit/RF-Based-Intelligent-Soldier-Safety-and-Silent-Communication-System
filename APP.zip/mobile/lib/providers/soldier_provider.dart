import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/soldier.dart';
import '../services/mock_data_service.dart';

final soldiersStreamProvider = StreamProvider<List<Soldier>>((ref) {
  final service = MockDataService.instance;
  return service.soldiersStream.map((_) => service.soldiers)
    ..listen((_) {});
});

final soldiersProvider = Provider<List<Soldier>>((ref) {
  final async = ref.watch(soldiersStreamProvider);
  return async.maybeWhen(
    data: (data) => data,
    orElse: () => MockDataService.instance.soldiers,
  );
});

final soldierSearchQueryProvider = StateProvider<String>((ref) => '');
final soldierStatusFilterProvider = StateProvider<String?>((ref) => null);

final filteredSoldiersProvider = Provider((ref) {
  final soldiers = ref.watch(soldiersProvider);
  final query = ref.watch(soldierSearchQueryProvider).toLowerCase();
  final statusFilter = ref.watch(soldierStatusFilterProvider);

  return soldiers.where((s) {
    final matchesQuery = query.isEmpty ||
        s.callsign.toLowerCase().contains(query) ||
        s.fullName.toLowerCase().contains(query) ||
        s.id.toLowerCase().contains(query);
    final matchesStatus = statusFilter == null || s.status.name == statusFilter;
    return matchesQuery && matchesStatus;
  }).toList();
});

final soldierByIdProvider = Provider.family((ref, String id) {
  final soldiers = ref.watch(soldiersProvider);
  return soldiers.firstWhere((s) => s.id == id);
});
