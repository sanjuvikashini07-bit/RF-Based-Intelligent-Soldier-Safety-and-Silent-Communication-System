import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/history_entry.dart';
import '../services/mock_data_service.dart';
import 'alert_provider.dart';

final historyProvider = Provider<List<HistoryEntry>>((ref) {
  ref.watch(alertsProvider); // refresh when new alerts arrive
  return MockDataService.instance.history;
});

final historySearchQueryProvider = StateProvider<String>((ref) => '');

final filteredHistoryProvider = Provider<List<HistoryEntry>>((ref) {
  final entries = ref.watch(historyProvider);
  final query = ref.watch(historySearchQueryProvider).toLowerCase();
  if (query.isEmpty) return entries;
  return entries
      .where((e) =>
          e.title.toLowerCase().contains(query) ||
          e.soldierCallsign.toLowerCase().contains(query) ||
          e.description.toLowerCase().contains(query))
      .toList();
});
