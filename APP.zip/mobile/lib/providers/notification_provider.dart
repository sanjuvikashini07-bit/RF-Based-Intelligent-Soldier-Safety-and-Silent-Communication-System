import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/notification_item.dart';
import '../services/mock_data_service.dart';

final notificationsStreamProvider = StreamProvider<List<NotificationItem>>((ref) {
  return MockDataService.instance.notificationsStream;
});

final notificationsProvider = Provider<List<NotificationItem>>((ref) {
  final async = ref.watch(notificationsStreamProvider);
  return async.maybeWhen(
    data: (data) => data,
    orElse: () => MockDataService.instance.notifications,
  );
});

final unreadNotificationsCountProvider = Provider<int>((ref) {
  return ref.watch(notificationsProvider).where((n) => !n.read).length;
});
