/// Represents a single entry in the mission/event history timeline.
class HistoryEntry {
  final String id;
  final String title;
  final String description;
  final String soldierCallsign;
  final DateTime timestamp;
  final String category; // alert, mission, system, message

  const HistoryEntry({
    required this.id,
    required this.title,
    required this.description,
    required this.soldierCallsign,
    required this.timestamp,
    required this.category,
  });

  factory HistoryEntry.fromJson(Map<String, dynamic> json) {
    return HistoryEntry(
      id: json['id'] as String,
      title: json['title'] as String,
      description: json['description'] as String,
      soldierCallsign: json['soldierCallsign'] as String,
      timestamp: DateTime.parse(json['timestamp'] as String),
      category: json['category'] as String,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'description': description,
        'soldierCallsign': soldierCallsign,
        'timestamp': timestamp.toIso8601String(),
        'category': category,
      };
}
