import 'enums.dart';

/// Represents a single soldier unit tracked by the command center.
class Soldier {
  final String id;
  final String callsign;
  final String fullName;
  final String rank;
  final String unit;
  final String avatarSeed;
  final SoldierStatus status;
  final int batteryLevel; // 0-100
  final int signalStrength; // 0-100 (RSSI mapped)
  final double? latitude;
  final double? longitude;
  final DateTime lastSeen;
  final double heartRate; // bpm, simulated from MPU6050 sensor fusion context
  final bool fallDetected;
  final DateTime deployedSince;

  const Soldier({
    required this.id,
    required this.callsign,
    required this.fullName,
    required this.rank,
    required this.unit,
    required this.avatarSeed,
    required this.status,
    required this.batteryLevel,
    required this.signalStrength,
    required this.lastSeen,
    required this.deployedSince,
    this.latitude,
    this.longitude,
    this.heartRate = 78,
    this.fallDetected = false,
  });

  Soldier copyWith({
    SoldierStatus? status,
    int? batteryLevel,
    int? signalStrength,
    double? latitude,
    double? longitude,
    DateTime? lastSeen,
    double? heartRate,
    bool? fallDetected,
  }) {
    return Soldier(
      id: id,
      callsign: callsign,
      fullName: fullName,
      rank: rank,
      unit: unit,
      avatarSeed: avatarSeed,
      status: status ?? this.status,
      batteryLevel: batteryLevel ?? this.batteryLevel,
      signalStrength: signalStrength ?? this.signalStrength,
      latitude: latitude ?? this.latitude,
      longitude: longitude ?? this.longitude,
      lastSeen: lastSeen ?? this.lastSeen,
      deployedSince: deployedSince,
      heartRate: heartRate ?? this.heartRate,
      fallDetected: fallDetected ?? this.fallDetected,
    );
  }

  factory Soldier.fromJson(Map<String, dynamic> json) {
    return Soldier(
      id: json['id'] as String,
      callsign: json['callsign'] as String,
      fullName: json['fullName'] as String,
      rank: json['rank'] as String,
      unit: json['unit'] as String,
      avatarSeed: json['avatarSeed'] as String? ?? json['id'] as String,
      status: SoldierStatus.values.firstWhere(
        (e) => e.name == json['status'],
        orElse: () => SoldierStatus.offline,
      ),
      batteryLevel: json['batteryLevel'] as int? ?? 0,
      signalStrength: json['signalStrength'] as int? ?? 0,
      latitude: (json['latitude'] as num?)?.toDouble(),
      longitude: (json['longitude'] as num?)?.toDouble(),
      lastSeen: DateTime.parse(json['lastSeen'] as String),
      deployedSince: DateTime.parse(json['deployedSince'] as String),
      heartRate: (json['heartRate'] as num?)?.toDouble() ?? 78,
      fallDetected: json['fallDetected'] as bool? ?? false,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'callsign': callsign,
        'fullName': fullName,
        'rank': rank,
        'unit': unit,
        'avatarSeed': avatarSeed,
        'status': status.name,
        'batteryLevel': batteryLevel,
        'signalStrength': signalStrength,
        'latitude': latitude,
        'longitude': longitude,
        'lastSeen': lastSeen.toIso8601String(),
        'deployedSince': deployedSince.toIso8601String(),
        'heartRate': heartRate,
        'fallDetected': fallDetected,
      };
}
