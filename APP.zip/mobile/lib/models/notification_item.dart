import 'enums.dart';

/// Represents an entry in the Notification Center.
class NotificationItem {
  final String id;
  final String title;
  final String body;
  final NotificationLevel level;
  final DateTime timestamp;
  final bool read;
  final String? relatedAlertId;

  const NotificationItem({
    required this.id,
    required this.title,
    required this.body,
    required this.level,
    required this.timestamp,
    this.read = false,
    this.relatedAlertId,
  });

  NotificationItem copyWith({bool? read}) {
    return NotificationItem(
      id: id,
      title: title,
      body: body,
      level: level,
      timestamp: timestamp,
      read: read ?? this.read,
      relatedAlertId: relatedAlertId,
    );
  }

  factory NotificationItem.fromJson(Map<String, dynamic> json) {
    return NotificationItem(
      id: json['id'] as String,
      title: json['title'] as String,
      body: json['body'] as String,
      level: NotificationLevel.values.firstWhere(
        (e) => e.name == json['level'],
        orElse: () => NotificationLevel.info,
      ),
      timestamp: DateTime.parse(json['timestamp'] as String),
      read: json['read'] as bool? ?? false,
      relatedAlertId: json['relatedAlertId'] as String?,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'body': body,
        'level': level.name,
        'timestamp': timestamp.toIso8601String(),
        'read': read,
        'relatedAlertId': relatedAlertId,
      };
}
