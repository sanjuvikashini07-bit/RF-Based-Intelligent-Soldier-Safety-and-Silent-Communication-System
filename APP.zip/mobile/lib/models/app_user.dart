import 'enums.dart';

/// Authenticated command-center user.
class AppUser {
  final String id;
  final String username;
  final String fullName;
  final UserRole role;
  final String department;
  final String? avatarUrl;

  const AppUser({
    required this.id,
    required this.username,
    required this.fullName,
    required this.role,
    required this.department,
    this.avatarUrl,
  });

  factory AppUser.fromJson(Map<String, dynamic> json) {
    return AppUser(
      id: json['id'] as String,
      username: json['username'] as String,
      fullName: json['fullName'] as String,
      role: UserRole.values.firstWhere(
        (e) => e.name == json['role'],
        orElse: () => UserRole.viewer,
      ),
      department: json['department'] as String? ?? 'Unassigned',
      avatarUrl: json['avatarUrl'] as String?,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'username': username,
        'fullName': fullName,
        'role': role.name,
        'department': department,
        'avatarUrl': avatarUrl,
      };
}
