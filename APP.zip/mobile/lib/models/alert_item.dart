import 'enums.dart';

/// Represents an alert or tactical message received from a soldier unit
/// via the RF -> Base Station -> Backend pipeline.
class AlertItem {
  final String id;
  final String soldierId;
  final String soldierCallsign;
  final String messageCode; // e.g. SOLDIER_DOWN
  final String messageLabel;
  final AlertPriority priority;
  final AlertStatus status;
  final DateTime timestamp;
  final DateTime? acknowledgedAt;
  final String? acknowledgedBy;
  final double? latitude;
  final double? longitude;
  final String? notes;

  const AlertItem({
    required this.id,
    required this.soldierId,
    required this.soldierCallsign,
    required this.messageCode,
    required this.messageLabel,
    required this.priority,
    required this.status,
    required this.timestamp,
    this.acknowledgedAt,
    this.acknowledgedBy,
    this.latitude,
    this.longitude,
    this.notes,
  });

  AlertItem copyWith({
    AlertStatus? status,
    DateTime? acknowledgedAt,
    String? acknowledgedBy,
    String? notes,
  }) {
    return AlertItem(
      id: id,
      soldierId: soldierId,
      soldierCallsign: soldierCallsign,
      messageCode: messageCode,
      messageLabel: messageLabel,
      priority: priority,
      status: status ?? this.status,
      timestamp: timestamp,
      acknowledgedAt: acknowledgedAt ?? this.acknowledgedAt,
      acknowledgedBy: acknowledgedBy ?? this.acknowledgedBy,
      latitude: latitude,
      longitude: longitude,
      notes: notes ?? this.notes,
    );
  }

  factory AlertItem.fromJson(Map<String, dynamic> json) {
    return AlertItem(
      id: json['id'] as String,
      soldierId: json['soldierId'] as String,
      soldierCallsign: json['soldierCallsign'] as String,
      messageCode: json['messageCode'] as String,
      messageLabel: json['messageLabel'] as String,
      priority: AlertPriority.values.firstWhere(
        (e) => e.name == json['priority'],
        orElse: () => AlertPriority.medium,
      ),
      status: AlertStatus.values.firstWhere(
        (e) => e.name == json['status'],
        orElse: () => AlertStatus.unacknowledged,
      ),
      timestamp: DateTime.parse(json['timestamp'] as String),
      acknowledgedAt: json['acknowledgedAt'] != null
          ? DateTime.parse(json['acknowledgedAt'] as String)
          : null,
      acknowledgedBy: json['acknowledgedBy'] as String?,
      latitude: (json['latitude'] as num?)?.toDouble(),
      longitude: (json['longitude'] as num?)?.toDouble(),
      notes: json['notes'] as String?,
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'soldierId': soldierId,
        'soldierCallsign': soldierCallsign,
        'messageCode': messageCode,
        'messageLabel': messageLabel,
        'priority': priority.name,
        'status': status.name,
        'timestamp': timestamp.toIso8601String(),
        'acknowledgedAt': acknowledgedAt?.toIso8601String(),
        'acknowledgedBy': acknowledgedBy,
        'latitude': latitude,
        'longitude': longitude,
        'notes': notes,
      };
}
