/// Operational status of a soldier unit.
enum SoldierStatus { active, standby, offline, emergency }

/// Priority level for alerts/messages.
enum AlertPriority { critical, high, medium, low }

/// Alert lifecycle state.
enum AlertStatus { unacknowledged, acknowledged, resolved }

/// Notification category.
enum NotificationLevel { critical, warning, info }

/// Role-based access control.
enum UserRole { commander, operator, viewer }

extension SoldierStatusX on SoldierStatus {
  String get label {
    switch (this) {
      case SoldierStatus.active:
        return 'Active';
      case SoldierStatus.standby:
        return 'Standby';
      case SoldierStatus.offline:
        return 'Offline';
      case SoldierStatus.emergency:
        return 'Emergency';
    }
  }
}

extension AlertPriorityX on AlertPriority {
  String get label {
    switch (this) {
      case AlertPriority.critical:
        return 'Critical';
      case AlertPriority.high:
        return 'High';
      case AlertPriority.medium:
        return 'Medium';
      case AlertPriority.low:
        return 'Low';
    }
  }
}

extension AlertStatusX on AlertStatus {
  String get label {
    switch (this) {
      case AlertStatus.unacknowledged:
        return 'Unacknowledged';
      case AlertStatus.acknowledged:
        return 'Acknowledged';
      case AlertStatus.resolved:
        return 'Resolved';
    }
  }
}

extension UserRoleX on UserRole {
  String get label {
    switch (this) {
      case UserRole.commander:
        return 'Commander';
      case UserRole.operator:
        return 'Operator';
      case UserRole.viewer:
        return 'Viewer';
    }
  }
}
