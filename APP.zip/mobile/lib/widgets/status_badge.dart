import 'package:flutter/material.dart';
import '../core/theme/app_colors.dart';
import '../models/enums.dart';

/// Small pill badge showing a soldier/alert status with a colored dot.
class StatusBadge extends StatelessWidget {
  final String label;
  final Color color;
  final bool pulse;

  const StatusBadge({super.key, required this.label, required this.color, this.pulse = false});

  factory StatusBadge.soldier(SoldierStatus status) {
    final color = switch (status) {
      SoldierStatus.active => AppColors.success,
      SoldierStatus.standby => AppColors.warning,
      SoldierStatus.offline => AppColors.offline,
      SoldierStatus.emergency => AppColors.emergency,
    };
    return StatusBadge(label: status.label, color: color, pulse: status == SoldierStatus.emergency);
  }

  factory StatusBadge.priority(AlertPriority priority) {
    final color = switch (priority) {
      AlertPriority.critical => AppColors.priorityCritical,
      AlertPriority.high => AppColors.priorityHigh,
      AlertPriority.medium => AppColors.priorityMedium,
      AlertPriority.low => AppColors.priorityLow,
    };
    return StatusBadge(label: priority.label, color: color);
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.5)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 7,
            height: 7,
            decoration: BoxDecoration(color: color, shape: BoxShape.circle),
          ),
          const SizedBox(width: 6),
          Text(
            label,
            style: TextStyle(color: color, fontSize: 12, fontWeight: FontWeight.w600),
          ),
        ],
      ),
    );
  }
}
