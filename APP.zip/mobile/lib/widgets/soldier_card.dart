import 'package:flutter/material.dart';
import 'package:percent_indicator/linear_percent_indicator.dart';
import '../core/theme/app_colors.dart';
import '../models/soldier.dart';
import 'glass_card.dart';
import 'status_badge.dart';

/// Card summarizing a soldier's live status in the Soldiers list.
class SoldierCard extends StatelessWidget {
  final Soldier soldier;
  final VoidCallback onTap;

  const SoldierCard({super.key, required this.soldier, required this.onTap});

  Color get _batteryColor {
    if (soldier.batteryLevel > 50) return AppColors.success;
    if (soldier.batteryLevel > 20) return AppColors.warning;
    return AppColors.danger;
  }

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      onTap: onTap,
      borderColor: soldier.status.name == 'emergency' ? AppColors.emergency : null,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 24,
                backgroundColor: AppColors.primary.withOpacity(0.15),
                child: Text(
                  soldier.callsign.substring(0, 1),
                  style: const TextStyle(
                    color: AppColors.primary,
                    fontWeight: FontWeight.bold,
                    fontSize: 18,
                  ),
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(soldier.callsign, style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 2),
                    Text('${soldier.rank} · ${soldier.fullName}',
                        style: Theme.of(context).textTheme.bodyMedium),
                  ],
                ),
              ),
              StatusBadge.soldier(soldier.status),
            ],
          ),
          const SizedBox(height: 16),
          Row(
            children: [
              Expanded(
                child: _MetricBar(
                  icon: Icons.battery_charging_full_rounded,
                  label: 'Battery',
                  percent: soldier.batteryLevel / 100,
                  color: _batteryColor,
                  valueLabel: '${soldier.batteryLevel}%',
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: _MetricBar(
                  icon: Icons.signal_cellular_alt_rounded,
                  label: 'Signal',
                  percent: soldier.signalStrength / 100,
                  color: AppColors.secondary,
                  valueLabel: '${soldier.signalStrength}%',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MetricBar extends StatelessWidget {
  final IconData icon;
  final String label;
  final double percent;
  final Color color;
  final String valueLabel;

  const _MetricBar({
    required this.icon,
    required this.label,
    required this.percent,
    required this.color,
    required this.valueLabel,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, size: 14, color: color),
            const SizedBox(width: 6),
            Text(label, style: const TextStyle(fontSize: 12, color: AppColors.textSecondary)),
            const Spacer(),
            Text(valueLabel, style: TextStyle(fontSize: 12, color: color, fontWeight: FontWeight.w600)),
          ],
        ),
        const SizedBox(height: 6),
        LinearPercentIndicator(
          padding: EdgeInsets.zero,
          lineHeight: 6,
          percent: percent.clamp(0, 1),
          backgroundColor: AppColors.glassFill,
          progressColor: color,
          barRadius: const Radius.circular(4),
          animation: true,
        ),
      ],
    );
  }
}
