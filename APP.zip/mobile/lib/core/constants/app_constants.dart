/// Global constant values used throughout the app.
class AppConstants {
  AppConstants._();

  static const String appName = 'SOLDIER SHIELD';
  static const String appTagline = 'RF-Based Intelligent Soldier Safety System';
  static const String appVersion = '1.0.0';

  // Backend base URL - override via --dart-define=API_BASE_URL=...
  static const String apiBaseUrl = String.fromEnvironment(
    'API_BASE_URL',
    defaultValue: 'http://10.0.2.2:5000/api/v1',
  );

  static const String wsUrl = String.fromEnvironment(
    'WS_URL',
    defaultValue: 'ws://10.0.2.2:5000',
  );

  // Secure storage keys
  static const String keyAccessToken = 'ss_access_token';
  static const String keyRefreshToken = 'ss_refresh_token';
  static const String keyRememberMe = 'ss_remember_me';
  static const String keySavedUsername = 'ss_saved_username';

  // Hive boxes
  static const String boxSettings = 'settings_box';
  static const String boxAlertsCache = 'alerts_cache_box';

  static const Duration apiTimeout = Duration(seconds: 15);
  static const Duration heartbeatInterval = Duration(seconds: 10);
}

/// Tactical quick messages transmitted from soldier units.
class TacticalMessages {
  TacticalMessages._();

  static const String needBackup = 'NEED_BACKUP';
  static const String enemySpotted = 'ENEMY_SPOTTED';
  static const String needMedicalHelp = 'NEED_MEDICAL_HELP';
  static const String missionCompleted = 'MISSION_COMPLETED';
  static const String soldierDown = 'SOLDIER_DOWN';

  static const List<String> all = [
    soldierDown,
    needMedicalHelp,
    enemySpotted,
    needBackup,
    missionCompleted,
  ];

  static String label(String code) {
    switch (code) {
      case needBackup:
        return 'Need Backup';
      case enemySpotted:
        return 'Enemy Spotted';
      case needMedicalHelp:
        return 'Need Medical Help';
      case missionCompleted:
        return 'Mission Completed';
      case soldierDown:
        return 'Soldier Down';
      default:
        return code;
    }
  }
}
