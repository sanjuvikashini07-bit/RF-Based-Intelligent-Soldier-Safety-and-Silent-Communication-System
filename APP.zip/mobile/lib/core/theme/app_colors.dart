import 'package:flutter/material.dart';

/// Central color palette for SOLDIER SHIELD.
/// Military-grade dark theme with tactical accent colors.
class AppColors {
  AppColors._();

  // Base backgrounds
  static const Color background = Color(0xFF0A0E12);
  static const Color surface = Color(0xFF12181F);
  static const Color surfaceElevated = Color(0xFF1A222B);
  static const Color glassFill = Color(0x1AFFFFFF);
  static const Color glassBorder = Color(0x33FFFFFF);

  // Brand / tactical accent
  static const Color primary = Color(0xFF00E676); // tactical green
  static const Color primaryDark = Color(0xFF00B85C);
  static const Color secondary = Color(0xFF00B0FF); // signal blue
  static const Color amber = Color(0xFFFFC107);

  // Status colors
  static const Color success = Color(0xFF00E676);
  static const Color warning = Color(0xFFFFB300);
  static const Color danger = Color(0xFFFF1744);
  static const Color emergency = Color(0xFFD50000);
  static const Color info = Color(0xFF29B6F6);
  static const Color offline = Color(0xFF5C6B73);

  // Text
  static const Color textPrimary = Color(0xFFEAF0F2);
  static const Color textSecondary = Color(0xFF9AA9B2);
  static const Color textMuted = Color(0xFF62727A);

  // Priority
  static const Color priorityCritical = Color(0xFFFF1744);
  static const Color priorityHigh = Color(0xFFFF6D00);
  static const Color priorityMedium = Color(0xFFFFC107);
  static const Color priorityLow = Color(0xFF00E676);

  static const List<Color> emergencyGradient = [
    Color(0xFF7F0000),
    Color(0xFFD50000),
  ];

  static const List<Color> backgroundGradient = [
    Color(0xFF0A0E12),
    Color(0xFF141B22),
  ];

  static const List<Color> primaryGradient = [
    Color(0xFF00E676),
    Color(0xFF00B0FF),
  ];
}
