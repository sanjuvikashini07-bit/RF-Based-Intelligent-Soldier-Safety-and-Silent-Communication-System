import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_colors.dart';
import '../../models/enums.dart';
import '../../providers/notification_provider.dart';
import '../../services/mock_data_service.dart';
import '../../widgets/glass_card.dart';

class NotificationCenterScreen extends ConsumerStatefulWidget {
  const NotificationCenterScreen({super.key});

  @override
  ConsumerState<NotificationCenterScreen> createState() => _NotificationCenterScreenState();
}

class _NotificationCenterScreenState extends ConsumerState<NotificationCenterScreen>
    with SingleTickerProviderStateMixin {
  late final TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 4, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Color _colorFor(NotificationLevel level) {
    switch (level) {
      case NotificationLevel.critical:
        return AppColors.danger;
      case NotificationLevel.warning:
        return AppColors.warning;
      case NotificationLevel.info:
        return AppColors.info;
    }
  }

  IconData _iconFor(NotificationLevel level) {
    switch (level) {
      case NotificationLevel.critical:
        return Icons.error_rounded;
      case NotificationLevel.warning:
        return Icons.warning_rounded;
      case NotificationLevel.info:
        return Icons.info_rounded;
    }
  }

  @override
  Widget build(BuildContext context) {
    final all = ref.watch(notificationsProvider);

    List filterFor(int tabIndex) {
      switch (tabIndex) {
        case 0:
          return all;
        case 1:
          return all.where((n) => n.level == NotificationLevel.critical).toList();
        case 2:
          return all.where((n) => !n.read).toList();
        default:
          return all.where((n) => n.read).toList();
      }
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Notification Center'),
        actions: [
          TextButton(
            onPressed: () => MockDataService.instance.markAllNotificationsRead(),
            child: const Text('Mark all read'),
          ),
        ],
        bottom: TabBar(
          controller: _tabController,
          isScrollable: true,
          indicatorColor: AppColors.primary,
          labelColor: AppColors.primary,
          unselectedLabelColor: AppColors.textMuted,
          tabs: const [
            Tab(text: 'All'),
            Tab(text: 'Critical'),
            Tab(text: 'Unread'),
            Tab(text: 'Read'),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: List.generate(4, (tabIndex) {
          final items = filterFor(tabIndex);
          if (items.isEmpty) {
            return const Center(
              child: Text('Nothing here.', style: TextStyle(color: AppColors.textMuted)),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.all(16),
            itemCount: items.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) {
              final n = items[i];
              return GlassCard(
                onTap: () => MockDataService.instance.markNotificationRead(n.id),
                borderColor: n.read ? null : _colorFor(n.level).withOpacity(0.6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(_iconFor(n.level), color: _colorFor(n.level)),
                    const SizedBox(width: 12),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(n.title, style: Theme.of(context).textTheme.titleMedium),
                          const SizedBox(height: 4),
                          Text(n.body, style: Theme.of(context).textTheme.bodyMedium),
                          const SizedBox(height: 6),
                          Text(
                            DateFormat('MMM d, hh:mm a').format(n.timestamp),
                            style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
                          ),
                        ],
                      ),
                    ),
                    if (!n.read)
                      Container(
                        width: 8,
                        height: 8,
                        decoration: BoxDecoration(color: _colorFor(n.level), shape: BoxShape.circle),
                      ),
                  ],
                ),
              );
            },
          );
        }),
      ),
    );
  }
}
