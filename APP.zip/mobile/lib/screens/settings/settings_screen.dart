import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../core/constants/app_constants.dart';
import '../../providers/settings_provider.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/animated_background.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/section_header.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);
    final notifier = ref.read(settingsProvider.notifier);

    return AnimatedBackground(
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text('Settings', style: Theme.of(context).textTheme.displayMedium),
            const SizedBox(height: 20),
            const SectionHeader(title: 'Appearance'),
            const SizedBox(height: 10),
            GlassCard(
              child: Row(
                children: [
                  const Icon(Icons.dark_mode_rounded, color: AppColors.primary),
                  const SizedBox(width: 12),
                  const Expanded(child: Text('Theme')),
                  Text('Dark (Tactical)', style: Theme.of(context).textTheme.bodyMedium),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const SectionHeader(title: 'Alerts'),
            const SizedBox(height: 10),
            GlassCard(
              child: Column(
                children: [
                  _switchRow(
                    context,
                    icon: Icons.notifications_active_rounded,
                    label: 'Push Notifications',
                    value: settings.notificationsEnabled,
                    onChanged: notifier.toggleNotifications,
                  ),
                  const Divider(height: 24),
                  _switchRow(
                    context,
                    icon: Icons.volume_up_rounded,
                    label: 'Alarm Sound',
                    value: settings.alarmSoundEnabled,
                    onChanged: notifier.toggleAlarm,
                  ),
                  const Divider(height: 24),
                  _switchRow(
                    context,
                    icon: Icons.vibration_rounded,
                    label: 'Vibration',
                    value: settings.vibrationEnabled,
                    onChanged: notifier.toggleVibration,
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const SectionHeader(title: 'Language'),
            const SizedBox(height: 10),
            GlassCard(
              child: DropdownButtonHideUnderline(
                child: DropdownButton<String>(
                  value: settings.language,
                  isExpanded: true,
                  dropdownColor: AppColors.surfaceElevated,
                  items: const ['English', 'Hindi', 'Tamil']
                      .map((l) => DropdownMenuItem(value: l, child: Text(l)))
                      .toList(),
                  onChanged: (v) {
                    if (v != null) notifier.setLanguage(v);
                  },
                ),
              ),
            ),
            const SizedBox(height: 20),
            const SectionHeader(title: 'About'),
            const SizedBox(height: 10),
            GlassCard(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(AppConstants.appName, style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 4),
                  Text('Version ${AppConstants.appVersion}', style: Theme.of(context).textTheme.bodyMedium),
                  const SizedBox(height: 4),
                  Text(AppConstants.appTagline, style: Theme.of(context).textTheme.bodyMedium),
                ],
              ),
            ),
            const SizedBox(height: 20),
            SizedBox(
              width: double.infinity,
              child: OutlinedButton.icon(
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppColors.danger,
                  side: const BorderSide(color: AppColors.danger),
                ),
                icon: const Icon(Icons.logout_rounded),
                label: const Text('Logout'),
                onPressed: () => ref.read(authProvider.notifier).logout(),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _switchRow(
    BuildContext context, {
    required IconData icon,
    required String label,
    required bool value,
    required ValueChanged<bool> onChanged,
  }) {
    return Row(
      children: [
        Icon(icon, color: AppColors.primary),
        const SizedBox(width: 12),
        Expanded(child: Text(label)),
        Switch(value: value, activeThumbColor: AppColors.primary, onChanged: onChanged),
      ],
    );
  }
}
