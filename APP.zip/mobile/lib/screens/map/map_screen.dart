import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/soldier_provider.dart';
import '../../widgets/status_badge.dart';

/// Full map screen. GPS module is part of the Future Scope (see README);
/// until an ESP32 GPS/GSM add-on is integrated, this renders a tactical
/// placeholder showing last-known relative soldier positions.
class MapScreen extends StatelessWidget {
  const MapScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Tactical Map')),
      body: const MapPreview(fullScreen: true),
    );
  }
}

class MapPreview extends ConsumerWidget {
  final bool fullScreen;
  const MapPreview({super.key, this.fullScreen = false});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final soldiers = ref.watch(soldiersProvider);
    final withGps = soldiers.where((s) => s.latitude != null && s.longitude != null).toList();

    return Container(
      color: AppColors.surface,
      child: Stack(
        children: [
          CustomPaint(
            painter: _RadarPainter(),
            size: Size.infinite,
          ),
          if (withGps.isEmpty)
            const Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.satellite_alt_rounded, color: AppColors.textMuted, size: 36),
                  SizedBox(height: 10),
                  Text('Waiting for GPS...', style: TextStyle(color: AppColors.textMuted)),
                ],
              ),
            )
          else
            ...withGps.map((s) {
              // Normalize lat/long jitter into a relative position within the box.
              final dx = ((s.longitude! * 1000) % 100).abs() / 100;
              final dy = ((s.latitude! * 1000) % 100).abs() / 100;
              return Positioned(
                left: dx * (fullScreen ? 320 : 220) + 10,
                top: dy * (fullScreen ? 420 : 120) + 10,
                child: Tooltip(
                  message: '${s.callsign} · ${s.status.label}',
                  child: Column(
                    children: [
                      Icon(
                        Icons.military_tech_rounded,
                        color: s.status.name == 'emergency' ? AppColors.emergency : AppColors.primary,
                        size: 22,
                      ),
                      const SizedBox(height: 2),
                      StatusBadge.soldier(s.status),
                    ],
                  ),
                ),
              );
            }),
          Positioned(
            bottom: 10,
            left: 10,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              decoration: BoxDecoration(
                color: Colors.black.withOpacity(0.4),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Text(
                'GPS module pending hardware integration (Future Scope)',
                style: TextStyle(fontSize: 10, color: AppColors.textMuted),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RadarPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = AppColors.primary.withOpacity(0.08)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;
    final center = Offset(size.width / 2, size.height / 2);
    for (var r = 20.0; r < size.longestSide; r += 40) {
      canvas.drawCircle(center, r, paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
