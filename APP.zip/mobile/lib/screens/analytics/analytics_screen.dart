import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../core/theme/app_colors.dart';
import '../../models/enums.dart';
import '../../providers/alert_provider.dart';
import '../../providers/soldier_provider.dart';
import '../../widgets/animated_background.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/section_header.dart';
import '../../widgets/stat_card.dart';

enum _Range { daily, weekly, monthly }

class AnalyticsScreen extends ConsumerStatefulWidget {
  const AnalyticsScreen({super.key});

  @override
  ConsumerState<AnalyticsScreen> createState() => _AnalyticsScreenState();
}

class _AnalyticsScreenState extends ConsumerState<AnalyticsScreen> {
  _Range _range = _Range.weekly;

  @override
  Widget build(BuildContext context) {
    final alerts = ref.watch(alertsProvider);
    final soldiers = ref.watch(soldiersProvider);

    final byPriority = {
      for (final p in AlertPriority.values) p: alerts.where((a) => a.priority == p).length,
    };

    final divisor = switch (_range) {
      _Range.daily => 1,
      _Range.weekly => 7,
      _Range.monthly => 30,
    };
    final points = List.generate(divisor > 10 ? 10 : divisor, (i) {
      final base = (alerts.length / divisor).clamp(0.5, 20);
      return FlSpot(i.toDouble(), (base * (0.6 + (i % 3) * 0.3)));
    });

    return AnimatedBackground(
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text('Analytics', style: Theme.of(context).textTheme.displayMedium),
            const SizedBox(height: 16),
            Row(
              children: _Range.values.map((r) {
                final selected = r == _range;
                return Expanded(
                  child: GestureDetector(
                    onTap: () => setState(() => _range = r),
                    child: Container(
                      margin: const EdgeInsets.only(right: 8),
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      decoration: BoxDecoration(
                        color: selected ? AppColors.primary.withOpacity(0.15) : AppColors.glassFill,
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: selected ? AppColors.primary : AppColors.glassBorder),
                      ),
                      child: Text(
                        r.name[0].toUpperCase() + r.name.substring(1),
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          color: selected ? AppColors.primary : AppColors.textSecondary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
            const SizedBox(height: 20),
            GridView.count(
              crossAxisCount: 2,
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              mainAxisSpacing: 14,
              crossAxisSpacing: 14,
              childAspectRatio: 1.35,
              children: [
                StatCard(label: 'Total Alerts', value: '${alerts.length}', icon: Icons.notifications_rounded, color: AppColors.primary),
                StatCard(label: 'Critical', value: '${byPriority[AlertPriority.critical]}', icon: Icons.priority_high_rounded, color: AppColors.emergency),
                StatCard(label: 'Units Deployed', value: '${soldiers.length}', icon: Icons.groups_rounded, color: AppColors.secondary),
                StatCard(label: 'Resolution Rate', value: alerts.isEmpty ? "0%" : "${((alerts.where((a) => a.status.name == 'resolved').length / alerts.length) * 100).round()}%", icon: Icons.task_alt_rounded, color: AppColors.success),
              ],
            ),
            const SizedBox(height: 24),
            const SectionHeader(title: 'Alert Volume'),
            const SizedBox(height: 12),
            GlassCard(
              child: SizedBox(
                height: 200,
                child: BarChart(
                  BarChartData(
                    gridData: const FlGridData(show: false),
                    borderData: FlBorderData(show: false),
                    titlesData: const FlTitlesData(
                      leftTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      rightTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      topTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                      bottomTitles: AxisTitles(sideTitles: SideTitles(showTitles: false)),
                    ),
                    barGroups: points
                        .map((p) => BarChartGroupData(x: p.x.toInt(), barRods: [
                              BarChartRodData(
                                toY: p.y,
                                color: AppColors.primary,
                                width: 14,
                                borderRadius: BorderRadius.circular(4),
                              ),
                            ]))
                        .toList(),
                  ),
                ),
              ),
            ),
            const SizedBox(height: 24),
            const SectionHeader(title: 'Alert Statistics by Priority'),
            const SizedBox(height: 12),
            GlassCard(
              child: SizedBox(
                height: 220,
                child: Row(
                  children: [
                    Expanded(
                      child: PieChart(
                        PieChartData(
                          sectionsSpace: 3,
                          centerSpaceRadius: 40,
                          sections: AlertPriority.values.map((p) {
                            final count = byPriority[p] ?? 0;
                            final color = switch (p) {
                              AlertPriority.critical => AppColors.priorityCritical,
                              AlertPriority.high => AppColors.priorityHigh,
                              AlertPriority.medium => AppColors.priorityMedium,
                              AlertPriority.low => AppColors.priorityLow,
                            };
                            return PieChartSectionData(
                              value: count.toDouble().clamp(0.001, double.infinity),
                              color: color,
                              title: count > 0 ? '$count' : '',
                              radius: 46,
                              titleStyle: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.black),
                            );
                          }).toList(),
                        ),
                      ),
                    ),
                    Expanded(
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: AlertPriority.values.map((p) {
                          final color = switch (p) {
                            AlertPriority.critical => AppColors.priorityCritical,
                            AlertPriority.high => AppColors.priorityHigh,
                            AlertPriority.medium => AppColors.priorityMedium,
                            AlertPriority.low => AppColors.priorityLow,
                          };
                          return Padding(
                            padding: const EdgeInsets.symmetric(vertical: 4),
                            child: Row(
                              children: [
                                Container(width: 10, height: 10, decoration: BoxDecoration(color: color, shape: BoxShape.circle)),
                                const SizedBox(width: 8),
                                Text(p.label, style: Theme.of(context).textTheme.bodyMedium),
                              ],
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}
