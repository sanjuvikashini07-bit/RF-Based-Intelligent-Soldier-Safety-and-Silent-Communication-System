import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/notification_provider.dart';
import '../../providers/alert_provider.dart';
import '../dashboard/dashboard_screen.dart';
import '../soldiers/soldiers_screen.dart';
import '../messages/messages_screen.dart';
import '../history/history_screen.dart';
import '../analytics/analytics_screen.dart';
import '../settings/settings_screen.dart';
import '../profile/profile_screen.dart';
import '../emergency/emergency_screen.dart';

/// Root shell hosting the bottom navigation and the 7 primary sections.
/// Also listens globally for emergency alerts and pushes the full-screen
/// Emergency view whenever a SOLDIER_DOWN / NEED_MEDICAL_HELP packet arrives.
class MainShell extends ConsumerStatefulWidget {
  const MainShell({super.key});

  @override
  ConsumerState<MainShell> createState() => _MainShellState();
}

class _MainShellState extends ConsumerState<MainShell> {
  int _index = 0;

  final _screens = const [
    DashboardScreen(),
    SoldiersScreen(),
    MessagesScreen(),
    HistoryScreen(),
    AnalyticsScreen(),
    SettingsScreen(),
    ProfileScreen(),
  ];

  final _navItems = const [
    _NavItem(icon: Icons.dashboard_rounded, label: 'Dashboard'),
    _NavItem(icon: Icons.shield_rounded, label: 'Soldiers'),
    _NavItem(icon: Icons.warning_amber_rounded, label: 'Alerts'),
    _NavItem(icon: Icons.history_rounded, label: 'History'),
    _NavItem(icon: Icons.analytics_rounded, label: 'Analytics'),
    _NavItem(icon: Icons.settings_rounded, label: 'Settings'),
    _NavItem(icon: Icons.person_rounded, label: 'Profile'),
  ];

  @override
  Widget build(BuildContext context) {
    // Global listener: navigate to full-screen Emergency alert.
    ref.listen(emergencyAlertProvider, (previous, next) {
      next.whenData((alert) {
        Navigator.of(context, rootNavigator: true).push(
          MaterialPageRoute(builder: (_) => EmergencyScreen(alert: alert)),
        );
      });
    });

    final unread = ref.watch(unreadNotificationsCountProvider);
    final activeAlerts = ref.watch(activeAlertsProvider).length;

    return Scaffold(
      body: IndexedStack(index: _index, children: _screens),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _index,
        onTap: (i) => setState(() => _index = i),
        items: List.generate(_navItems.length, (i) {
          final item = _navItems[i];
          Widget icon = Icon(item.icon);
          if (i == 2 && activeAlerts > 0) {
            icon = _Badge(count: activeAlerts, child: icon);
          }
          if (i == 5 && unread > 0 && false) {
            // Settings has no badge; placeholder kept out intentionally.
          }
          return BottomNavigationBarItem(icon: icon, label: item.label);
        }),
      ),
    );
  }
}

class _NavItem {
  final IconData icon;
  final String label;
  const _NavItem({required this.icon, required this.label});
}

class _Badge extends StatelessWidget {
  final int count;
  final Widget child;
  const _Badge({required this.count, required this.child});

  @override
  Widget build(BuildContext context) {
    return Stack(
      clipBehavior: Clip.none,
      children: [
        child,
        Positioned(
          right: -6,
          top: -4,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 1),
            decoration: BoxDecoration(color: AppColors.danger, borderRadius: BorderRadius.circular(10)),
            constraints: const BoxConstraints(minWidth: 16),
            child: Text(
              count > 9 ? '9+' : '$count',
              style: const TextStyle(color: Colors.white, fontSize: 10, fontWeight: FontWeight.bold),
              textAlign: TextAlign.center,
            ),
          ),
        ),
      ],
    );
  }
}
