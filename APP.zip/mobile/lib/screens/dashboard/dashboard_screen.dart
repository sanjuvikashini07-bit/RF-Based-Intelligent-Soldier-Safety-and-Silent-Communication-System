import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../core/theme/app_colors.dart';
import '../../core/constants/app_constants.dart';
import '../../models/enums.dart';
import '../../providers/soldier_provider.dart';
import '../../providers/alert_provider.dart';
import '../../providers/notification_provider.dart';
import '../../widgets/animated_background.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/stat_card.dart';
import '../../widgets/section_header.dart';
import '../../widgets/status_badge.dart';
import '../notifications/notification_center_screen.dart';
import '../map/map_screen.dart';

class DashboardScreen extends ConsumerStatefulWidget {
  const DashboardScreen({super.key});

  @override
  ConsumerState<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends ConsumerState<DashboardScreen> {
  late Timer _clockTimer;
  DateTime _now = DateTime.now();

  @override
  void initState() {
    super.initState();
    _clockTimer = Timer.periodic(const Duration(seconds: 1), (_) {
      setState(() => _now = DateTime.now());
    });
  }

  @override
  void dispose() {
    _clockTimer.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final soldiers = ref.watch(soldiersProvider);
    final activeAlerts = ref.watch(activeAlertsProvider);
    final allAlerts = ref.watch(alertsProvider);
    final unread = ref.watch(unreadNotificationsCountProvider);

    final connected = soldiers.where((s) => s.status != SoldierStatus.offline).length;
    final emergencyCount = soldiers.where((s) => s.status == SoldierStatus.emergency).length;
    final todayAlerts = allAlerts.where((a) =>
        a.timestamp.day == DateTime.now().day &&
        a.timestamp.month == DateTime.now().month).length;
    final avgBattery = soldiers.isEmpty
        ? 0
        : (soldiers.map((s) => s.batteryLevel).reduce((a, b) => a + b) / soldiers.length).round();

    return AnimatedBackground(
      child: SafeArea(
        child: CustomScrollView(
          slivers: [
            SliverAppBar(
              floating: true,
              backgroundColor: Colors.transparent,
              title: Text(AppConstants.appName),
              actions: [
                IconButton(
                  icon: Badge(
                    label: Text('$unread'),
                    isLabelVisible: unread > 0,
                    child: const Icon(Icons.notifications_outlined),
                  ),
                  onPressed: () => Navigator.of(context).push(
                    MaterialPageRoute(builder: (_) => const NotificationCenterScreen()),
                  ),
                ),
                const SizedBox(width: 8),
              ],
            ),
            SliverPadding(
              padding: const EdgeInsets.all(16),
              sliver: SliverList(
                delegate: SliverChildListDelegate([
                  _buildClockCard(context),
                  const SizedBox(height: 16),
                  _buildMissionStatusBar(context, emergencyCount),
                  const SizedBox(height: 24),
                  const SectionHeader(title: 'Overview'),
                  const SizedBox(height: 12),
                  GridView.count(
                    crossAxisCount: 2,
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    mainAxisSpacing: 14,
                    crossAxisSpacing: 14,
                    childAspectRatio: 1.35,
                    children: [
                      StatCard(
                        label: 'Connected Soldiers',
                        value: '$connected / ${soldiers.length}',
                        icon: Icons.groups_rounded,
                        color: AppColors.primary,
                      ),
                      StatCard(
                        label: "Today's Alerts",
                        value: '$todayAlerts',
                        icon: Icons.notifications_active_rounded,
                        color: AppColors.warning,
                      ),
                      StatCard(
                        label: 'Active Emergencies',
                        value: '$emergencyCount',
                        icon: Icons.emergency_rounded,
                        color: AppColors.emergency,
                      ),
                      StatCard(
                        label: 'Avg. Battery',
                        value: '$avgBattery%',
                        icon: Icons.battery_full_rounded,
                        color: AppColors.secondary,
                      ),
                    ],
                  ),
                  const SizedBox(height: 24),
                  const SectionHeader(title: 'Alert Trend (Last 7 Days)'),
                  const SizedBox(height: 12),
                  _buildAlertTrendChart(context, allAlerts.length),
                  const SizedBox(height: 24),
                  SectionHeader(
                    title: 'Active Alerts',
                    actionLabel: activeAlerts.isEmpty ? null : 'View All',
                    onAction: () {},
                  ),
                  const SizedBox(height: 12),
                  if (activeAlerts.isEmpty)
                    GlassCard(
                      child: Row(
                        children: const [
                          Icon(Icons.check_circle_rounded, color: AppColors.success),
                          SizedBox(width: 12),
                          Text('No active alerts. All units nominal.'),
                        ],
                      ),
                    )
                  else
                    ...activeAlerts.take(4).map(
                          (a) => Padding(
                            padding: const EdgeInsets.only(bottom: 10),
                            child: GlassCard(
                              borderColor: a.priority == AlertPriority.critical
                                  ? AppColors.emergency
                                  : null,
                              child: Row(
                                children: [
                                  Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(a.messageLabel,
                                            style: Theme.of(context).textTheme.titleMedium),
                                        const SizedBox(height: 4),
                                        Text(
                                          '${a.soldierCallsign} · ${DateFormat('hh:mm a').format(a.timestamp)}',
                                          style: Theme.of(context).textTheme.bodyMedium,
                                        ),
                                      ],
                                    ),
                                  ),
                                  StatusBadge.priority(a.priority),
                                ],
                              ),
                            ),
                          ),
                        ),
                  const SizedBox(height: 24),
                  const SectionHeader(title: 'Live Map'),
                  const SizedBox(height: 12),
                  GlassCard(
                    padding: EdgeInsets.zero,
                    child: SizedBox(
                      height: 180,
                      child: ClipRRect(
                        borderRadius: BorderRadius.circular(18),
                        child: const MapPreview(),
                      ),
                    ),
                  ),
                  const SizedBox(height: 24),
                ]),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildClockCard(BuildContext context) {
    return GlassCard(
      gradient: const LinearGradient(
        colors: [Color(0x2200E676), Color(0x1100B0FF)],
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(DateFormat('hh:mm:ss a').format(_now),
                  style: Theme.of(context).textTheme.displayLarge?.copyWith(fontSize: 30)),
              const SizedBox(height: 4),
              Text(DateFormat('EEEE, MMMM d, yyyy').format(_now),
                  style: Theme.of(context).textTheme.bodyMedium),
            ],
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: const [
              StatusBadge(label: 'MISSION ACTIVE', color: AppColors.success),
              SizedBox(height: 8),
              StatusBadge(label: 'SYSTEM ONLINE', color: AppColors.secondary),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildMissionStatusBar(BuildContext context, int emergencyCount) {
    final isEmergency = emergencyCount > 0;
    return GlassCard(
      borderColor: isEmergency ? AppColors.emergency : AppColors.glassBorder,
      child: Row(
        children: [
          Icon(
            isEmergency ? Icons.warning_rounded : Icons.verified_user_rounded,
            color: isEmergency ? AppColors.emergency : AppColors.success,
          ),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              isEmergency
                  ? '$emergencyCount soldier(s) require immediate attention'
                  : 'All systems nominal — no active emergencies',
              style: Theme.of(context).textTheme.bodyLarge,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAlertTrendChart(BuildContext context, int totalAlerts) {
    final base = (totalAlerts / 3).clamp(1, 10).toDouble();
    final spots = List.generate(7, (i) {
      final wave = (i % 3 == 0) ? base * 1.4 : base * 0.7 + i * 0.3;
      return FlSpot(i.toDouble(), wave);
    });

    return GlassCard(
      child: SizedBox(
        height: 180,
        child: LineChart(
          LineChartData(
            gridData: const FlGridData(show: false),
            titlesData: FlTitlesData(
              leftTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
              rightTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
              topTitles: const AxisTitles(sideTitles: SideTitles(showTitles: false)),
              bottomTitles: AxisTitles(
                sideTitles: SideTitles(
                  showTitles: true,
                  getTitlesWidget: (value, meta) {
                    const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
                    final idx = value.toInt();
                    if (idx < 0 || idx >= days.length) return const SizedBox.shrink();
                    return Padding(
                      padding: const EdgeInsets.only(top: 8),
                      child: Text(days[idx],
                          style: const TextStyle(color: AppColors.textMuted, fontSize: 11)),
                    );
                  },
                ),
              ),
            ),
            borderData: FlBorderData(show: false),
            lineBarsData: [
              LineChartBarData(
                spots: spots,
                isCurved: true,
                color: AppColors.primary,
                barWidth: 3,
                dotData: const FlDotData(show: false),
                belowBarData: BarAreaData(
                  show: true,
                  gradient: LinearGradient(
                    colors: [AppColors.primary.withOpacity(0.25), Colors.transparent],
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
