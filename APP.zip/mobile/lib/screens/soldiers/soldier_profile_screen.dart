import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/soldier_provider.dart';
import '../../providers/alert_provider.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/status_badge.dart';
import '../../widgets/section_header.dart';

class SoldierProfileScreen extends ConsumerWidget {
  final String soldierId;
  const SoldierProfileScreen({super.key, required this.soldierId});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final soldier = ref.watch(soldierByIdProvider(soldierId));
    final alerts = ref.watch(alertsProvider).where((a) => a.soldierId == soldierId).toList();

    return Scaffold(
      appBar: AppBar(
        title: Text(soldier.callsign),
        actions: [
          IconButton(
            icon: const Icon(Icons.description_outlined),
            tooltip: 'Generate Report',
            onPressed: () => ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Report generated for ${soldier.callsign}.')),
            ),
          ),
        ],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            GlassCard(
              child: Column(
                children: [
                  Row(
                    children: [
                      CircleAvatar(
                        radius: 32,
                        backgroundColor: AppColors.primary.withOpacity(0.15),
                        child: Text(
                          soldier.callsign.substring(0, 1),
                          style: const TextStyle(color: AppColors.primary, fontSize: 26, fontWeight: FontWeight.bold),
                        ),
                      ),
                      const SizedBox(width: 16),
                      Expanded(
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(soldier.fullName, style: Theme.of(context).textTheme.titleLarge),
                            const SizedBox(height: 4),
                            Text('${soldier.rank} · ${soldier.unit}',
                                style: Theme.of(context).textTheme.bodyMedium),
                            const SizedBox(height: 8),
                            StatusBadge.soldier(soldier.status),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(child: _infoTile(context, 'Soldier ID', soldier.id)),
                const SizedBox(width: 12),
                Expanded(child: _infoTile(context, 'Deployed', DateFormat('MMM d').format(soldier.deployedSince))),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _infoTile(context, 'Battery', '${soldier.batteryLevel}%')),
                const SizedBox(width: 12),
                Expanded(child: _infoTile(context, 'Signal', '${soldier.signalStrength}%')),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(child: _infoTile(context, 'Heart Rate', '${soldier.heartRate.round()} bpm')),
                const SizedBox(width: 12),
                Expanded(child: _infoTile(context, 'Last Seen', DateFormat('hh:mm a').format(soldier.lastSeen))),
              ],
            ),
            const SizedBox(height: 24),
            const SectionHeader(title: 'Message Timeline'),
            const SizedBox(height: 12),
            if (alerts.isEmpty)
              const GlassCard(child: Text('No messages recorded for this soldier yet.'))
            else
              ...alerts.map(
                (a) => Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: GlassCard(
                    child: Row(
                      children: [
                        Container(
                          width: 10,
                          height: 10,
                          margin: const EdgeInsets.only(right: 12),
                          decoration: BoxDecoration(
                            color: a.priority.name == 'critical' ? AppColors.emergency : AppColors.primary,
                            shape: BoxShape.circle,
                          ),
                        ),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(a.messageLabel, style: Theme.of(context).textTheme.titleMedium),
                              Text(
                                DateFormat('MMM d, hh:mm a').format(a.timestamp),
                                style: Theme.of(context).textTheme.bodyMedium,
                              ),
                            ],
                          ),
                        ),
                        StatusBadge.priority(a.priority),
                      ],
                    ),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _infoTile(BuildContext context, String label, String value) {
    return GlassCard(
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(label, style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 4),
          Text(value, style: Theme.of(context).textTheme.titleMedium),
        ],
      ),
    );
  }
}
