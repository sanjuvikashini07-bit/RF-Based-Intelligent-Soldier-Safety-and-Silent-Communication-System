import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../models/enums.dart';
import '../../providers/soldier_provider.dart';
import '../../widgets/animated_background.dart';
import '../../widgets/soldier_card.dart';
import 'soldier_profile_screen.dart';

class SoldiersScreen extends ConsumerWidget {
  const SoldiersScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final soldiers = ref.watch(filteredSoldiersProvider);
    final statusFilter = ref.watch(soldierStatusFilterProvider);

    return AnimatedBackground(
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Row(
                children: [
                  Text('Soldiers', style: Theme.of(context).textTheme.displayMedium),
                  const Spacer(),
                  Text('${soldiers.length} units',
                      style: Theme.of(context).textTheme.bodyMedium),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                onChanged: (v) => ref.read(soldierSearchQueryProvider.notifier).state = v,
                decoration: const InputDecoration(
                  hintText: 'Search by callsign, name, or ID...',
                  prefixIcon: Icon(Icons.search, color: AppColors.textSecondary),
                ),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 40,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  _FilterChip(
                    label: 'All',
                    selected: statusFilter == null,
                    onTap: () => ref.read(soldierStatusFilterProvider.notifier).state = null,
                  ),
                  const SizedBox(width: 8),
                  ...SoldierStatus.values.map(
                    (s) => Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: _FilterChip(
                        label: s.label,
                        selected: statusFilter == s.name,
                        onTap: () => ref.read(soldierStatusFilterProvider.notifier).state = s.name,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Expanded(
              child: soldiers.isEmpty
                  ? const Center(
                      child: Text('No soldiers match your search.',
                          style: TextStyle(color: AppColors.textMuted)),
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                      itemCount: soldiers.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (context, index) {
                        final soldier = soldiers[index];
                        return SoldierCard(
                          soldier: soldier,
                          onTap: () => Navigator.of(context).push(
                            MaterialPageRoute(
                              builder: (_) => SoldierProfileScreen(soldierId: soldier.id),
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _FilterChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: selected ? AppColors.primary.withOpacity(0.15) : AppColors.glassFill,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: selected ? AppColors.primary : AppColors.glassBorder),
        ),
        child: Center(
          child: Text(
            label,
            style: TextStyle(
              color: selected ? AppColors.primary : AppColors.textSecondary,
              fontWeight: FontWeight.w600,
              fontSize: 13,
            ),
          ),
        ),
      ),
    );
  }
}
