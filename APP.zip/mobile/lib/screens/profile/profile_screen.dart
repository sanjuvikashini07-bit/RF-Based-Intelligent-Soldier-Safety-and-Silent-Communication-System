import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../core/theme/app_colors.dart';
import '../../core/constants/app_constants.dart';
import '../../providers/auth_provider.dart';
import '../../widgets/animated_background.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/section_header.dart';

class ProfileScreen extends ConsumerWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(authProvider).user;

    return AnimatedBackground(
      child: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text('Profile', style: Theme.of(context).textTheme.displayMedium),
            const SizedBox(height: 20),
            GlassCard(
              child: Column(
                children: [
                  CircleAvatar(
                    radius: 36,
                    backgroundColor: AppColors.primary.withOpacity(0.15),
                    child: const Icon(Icons.military_tech_rounded, color: AppColors.primary, size: 36),
                  ),
                  const SizedBox(height: 12),
                  Text(user?.fullName ?? 'Command Operator', style: Theme.of(context).textTheme.titleLarge),
                  const SizedBox(height: 4),
                  Text(user?.role.label ?? 'Operator', style: Theme.of(context).textTheme.bodyMedium),
                  const SizedBox(height: 4),
                  Text(user?.department ?? 'Tactical Command Division', style: Theme.of(context).textTheme.bodyMedium),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const SectionHeader(title: 'Project Information'),
            const SizedBox(height: 10),
            GlassCard(
              child: Column(
                children: [
                  _row(context, 'Application', AppConstants.appName),
                  const Divider(height: 24),
                  _row(context, 'Version', AppConstants.appVersion),
                  const Divider(height: 24),
                  _row(context, 'Project Type', 'RF-Based IoT Safety System'),
                  const Divider(height: 24),
                  _row(context, 'Department', 'Electronics & Communication Engineering'),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const SectionHeader(title: 'Development Credits'),
            const SizedBox(height: 10),
            GlassCard(
              child: Column(
                children: [
                  _row(context, 'Developer', 'ECE Project Team'),
                  const Divider(height: 24),
                  _row(context, 'Project Guide', 'Faculty Guide, Dept. of ECE'),
                  const Divider(height: 24),
                  _row(context, 'Hardware Platform', 'ESP32 · Arduino UNO · 433MHz RF'),
                ],
              ),
            ),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }

  Widget _row(BuildContext context, String label, String value) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Text(label, style: Theme.of(context).textTheme.bodyMedium),
        Text(value, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontSize: 14)),
      ],
    );
  }
}
