import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_colors.dart';
import '../../core/constants/app_constants.dart';
import '../../models/enums.dart';
import '../../providers/alert_provider.dart';
import '../../providers/soldier_provider.dart';
import '../../widgets/animated_background.dart';
import '../../widgets/glass_card.dart';
import '../../widgets/status_badge.dart';

class MessagesScreen extends ConsumerWidget {
  const MessagesScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final alerts = ref.watch(alertsProvider);

    return AnimatedBackground(
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Row(
                children: [
                  Text('Tactical Messages', style: Theme.of(context).textTheme.displayMedium),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.send_rounded, color: AppColors.primary),
                    tooltip: 'Simulate Incoming Message',
                    onPressed: () => _showSimulateSheet(context, ref),
                  ),
                ],
              ),
            ),
            Expanded(
              child: alerts.isEmpty
                  ? const Center(
                      child: Text('No messages received yet.', style: TextStyle(color: AppColors.textMuted)),
                    )
                  : ListView.separated(
                      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
                      itemCount: alerts.length,
                      separatorBuilder: (_, __) => const SizedBox(height: 12),
                      itemBuilder: (context, index) {
                        final a = alerts[index];
                        return GlassCard(
                          borderColor: a.priority == AlertPriority.critical ? AppColors.emergency : null,
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Text(a.messageLabel,
                                        style: Theme.of(context).textTheme.titleMedium),
                                  ),
                                  StatusBadge.priority(a.priority),
                                ],
                              ),
                              const SizedBox(height: 8),
                              Row(
                                children: [
                                  const Icon(Icons.badge_outlined, size: 14, color: AppColors.textSecondary),
                                  const SizedBox(width: 4),
                                  Text(a.soldierCallsign, style: Theme.of(context).textTheme.bodyMedium),
                                  const SizedBox(width: 16),
                                  const Icon(Icons.access_time, size: 14, color: AppColors.textSecondary),
                                  const SizedBox(width: 4),
                                  Text(DateFormat('MMM d, hh:mm a').format(a.timestamp),
                                      style: Theme.of(context).textTheme.bodyMedium),
                                ],
                              ),
                              const SizedBox(height: 12),
                              Row(
                                children: [
                                  StatusBadge(
                                    label: a.status.label,
                                    color: a.status == AlertStatus.resolved
                                        ? AppColors.success
                                        : a.status == AlertStatus.acknowledged
                                            ? AppColors.info
                                            : AppColors.danger,
                                  ),
                                  const Spacer(),
                                  if (a.status == AlertStatus.unacknowledged)
                                    TextButton(
                                      onPressed: () => ref
                                          .read(alertActionsProvider)
                                          .acknowledge(a.id, 'CMD-OPERATOR'),
                                      child: const Text('Acknowledge'),
                                    ),
                                ],
                              ),
                            ],
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  void _showSimulateSheet(BuildContext context, WidgetRef ref) {
    final soldiers = ref.read(soldiersProvider);
    String? selectedSoldierId = soldiers.isNotEmpty ? soldiers.first.id : null;

    showModalBottomSheet(
      context: context,
      backgroundColor: AppColors.surfaceElevated,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      builder: (ctx) {
        return StatefulBuilder(
          builder: (ctx, setModalState) {
            return Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Simulate Incoming RF Message', style: Theme.of(ctx).textTheme.titleLarge),
                  const SizedBox(height: 4),
                  const Text(
                    'For demo purposes — emulates a packet decoded by the HT12D base station receiver.',
                    style: TextStyle(color: AppColors.textMuted, fontSize: 12),
                  ),
                  const SizedBox(height: 16),
                  DropdownButtonFormField<String>(
                    value: selectedSoldierId,
                    dropdownColor: AppColors.surfaceElevated,
                    decoration: const InputDecoration(labelText: 'Soldier'),
                    items: soldiers
                        .map((s) => DropdownMenuItem(value: s.id, child: Text(s.callsign)))
                        .toList(),
                    onChanged: (v) => setModalState(() => selectedSoldierId = v),
                  ),
                  const SizedBox(height: 16),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: TacticalMessages.all.map((code) {
                      return ActionChip(
                        label: Text(TacticalMessages.label(code)),
                        backgroundColor: AppColors.glassFill,
                        onPressed: selectedSoldierId == null
                            ? null
                            : () {
                                ref.read(alertActionsProvider).trigger(selectedSoldierId!, code);
                                Navigator.of(ctx).pop();
                              },
                      );
                    }).toList(),
                  ),
                ],
              ),
            );
          },
        );
      },
    );
  }
}
