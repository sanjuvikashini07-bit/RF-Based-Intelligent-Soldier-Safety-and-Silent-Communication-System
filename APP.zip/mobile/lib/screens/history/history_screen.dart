import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_colors.dart';
import '../../providers/history_provider.dart';
import '../../widgets/animated_background.dart';
import '../../widgets/glass_card.dart';

class HistoryScreen extends ConsumerWidget {
  const HistoryScreen({super.key});

  IconData _iconFor(String category) {
    switch (category) {
      case 'alert':
        return Icons.warning_amber_rounded;
      case 'mission':
        return Icons.flag_rounded;
      case 'system':
        return Icons.settings_suggest_rounded;
      default:
        return Icons.message_rounded;
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final entries = ref.watch(filteredHistoryProvider);

    return AnimatedBackground(
      child: SafeArea(
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Row(
                children: [
                  Text('History', style: Theme.of(context).textTheme.displayMedium),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.picture_as_pdf_outlined, color: AppColors.textSecondary),
                    tooltip: 'Export PDF',
                    onPressed: () => _exportSnack(context, 'PDF'),
                  ),
                  IconButton(
                    icon: const Icon(Icons.table_chart_outlined, color: AppColors.textSecondary),
                    tooltip: 'Export CSV',
                    onPressed: () => _exportSnack(context, 'CSV'),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: TextField(
                onChanged: (v) => ref.read(historySearchQueryProvider.notifier).state = v,
                decoration: const InputDecoration(
                  hintText: 'Search history...',
                  prefixIcon: Icon(Icons.search, color: AppColors.textSecondary),
                ),
              ),
            ),
            const SizedBox(height: 12),
            Expanded(
              child: entries.isEmpty
                  ? const Center(child: Text('No history entries found.', style: TextStyle(color: AppColors.textMuted)))
                  : ListView.builder(
                      padding: const EdgeInsets.fromLTRB(16, 0, 16, 24),
                      itemCount: entries.length,
                      itemBuilder: (context, index) {
                        final e = entries[index];
                        return Padding(
                          padding: const EdgeInsets.only(bottom: 12),
                          child: IntrinsicHeight(
                            child: Row(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Column(
                                  children: [
                                    Container(
                                      width: 34,
                                      height: 34,
                                      decoration: BoxDecoration(
                                        color: AppColors.primary.withOpacity(0.15),
                                        shape: BoxShape.circle,
                                      ),
                                      child: Icon(_iconFor(e.category), size: 16, color: AppColors.primary),
                                    ),
                                    if (index != entries.length - 1)
                                      const Expanded(
                                        child: VerticalDivider(color: AppColors.glassBorder, thickness: 1),
                                      ),
                                  ],
                                ),
                                const SizedBox(width: 14),
                                Expanded(
                                  child: GlassCard(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text(e.title, style: Theme.of(context).textTheme.titleMedium),
                                        const SizedBox(height: 4),
                                        Text(e.description, style: Theme.of(context).textTheme.bodyMedium),
                                        const SizedBox(height: 8),
                                        Text(
                                          DateFormat('MMM d, yyyy · hh:mm a').format(e.timestamp),
                                          style: const TextStyle(fontSize: 11, color: AppColors.textMuted),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  void _exportSnack(BuildContext context, String format) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('History exported as $format.')),
    );
  }
}
