import 'dart:async';
import 'dart:math';
import '../models/soldier.dart';
import '../models/alert_item.dart';
import '../models/notification_item.dart';
import '../models/history_entry.dart';
import '../models/enums.dart';
import '../core/constants/app_constants.dart';

/// Simulates the live telemetry that would normally arrive from the
/// backend over WebSocket (which itself relays RF packets captured by
/// the Arduino UNO base station). This lets the Command Center run and
/// demo end-to-end before the backend/hardware are connected, and is
/// swapped out for [ApiClient] + WebSocket once the backend is live.
class MockDataService {
  MockDataService._internal() {
    _seed();
  }
  static final MockDataService instance = MockDataService._internal();

  final _random = Random();
  final List<Soldier> _soldiers = [];
  final List<AlertItem> _alerts = [];
  final List<NotificationItem> _notifications = [];
  final List<HistoryEntry> _history = [];

  final _soldiersController = StreamController<List<Soldier>>.broadcast();
  final _alertsController = StreamController<List<AlertItem>>.broadcast();
  final _notificationsController = StreamController<List<NotificationItem>>.broadcast();
  final _emergencyController = StreamController<AlertItem>.broadcast();

  Timer? _heartbeatTimer;

  Stream<List<Soldier>> get soldiersStream => _soldiersController.stream;
  Stream<List<AlertItem>> get alertsStream => _alertsController.stream;
  Stream<List<NotificationItem>> get notificationsStream => _notificationsController.stream;
  Stream<AlertItem> get emergencyStream => _emergencyController.stream;

  List<Soldier> get soldiers => List.unmodifiable(_soldiers);
  List<AlertItem> get alerts => List.unmodifiable(_alerts..sort((a, b) => b.timestamp.compareTo(a.timestamp)));
  List<NotificationItem> get notifications => List.unmodifiable(_notifications);
  List<HistoryEntry> get history => List.unmodifiable(_history..sort((a, b) => b.timestamp.compareTo(a.timestamp)));

  static const _callsigns = ['ALPHA-1', 'BRAVO-2', 'CHARLIE-3', 'DELTA-4', 'ECHO-5', 'FOXTROT-6'];
  static const _ranks = ['Sergeant', 'Corporal', 'Lieutenant', 'Captain', 'Private', 'Major'];
  static const _names = [
    'Arjun Rao', 'Vikram Singh', 'Karan Mehta', 'Rohan Nair',
    'Aditya Verma', 'Sameer Khan',
  ];

  void _seed() {
    for (var i = 0; i < _callsigns.length; i++) {
      _soldiers.add(
        Soldier(
          id: 'SLD-${1000 + i}',
          callsign: _callsigns[i],
          fullName: _names[i],
          rank: _ranks[i],
          unit: '${(i % 3) + 1}st Reconnaissance Unit',
          avatarSeed: _callsigns[i],
          status: i == 0 ? SoldierStatus.active : SoldierStatus.values[_random.nextInt(3)],
          batteryLevel: 40 + _random.nextInt(60),
          signalStrength: 50 + _random.nextInt(50),
          latitude: 13.0827 + (_random.nextDouble() - 0.5) * 0.05,
          longitude: 80.2707 + (_random.nextDouble() - 0.5) * 0.05,
          lastSeen: DateTime.now().subtract(Duration(seconds: _random.nextInt(120))),
          deployedSince: DateTime.now().subtract(Duration(hours: 6 + _random.nextInt(48))),
          heartRate: 65 + _random.nextInt(40).toDouble(),
        ),
      );
    }

    // Seed a few historical alerts
    final seedMessages = [
      TacticalMessages.missionCompleted,
      TacticalMessages.needBackup,
      TacticalMessages.enemySpotted,
    ];
    for (var i = 0; i < seedMessages.length; i++) {
      final soldier = _soldiers[i % _soldiers.length];
      final alert = AlertItem(
        id: 'ALT-${DateTime.now().millisecondsSinceEpoch - i * 100000}',
        soldierId: soldier.id,
        soldierCallsign: soldier.callsign,
        messageCode: seedMessages[i],
        messageLabel: TacticalMessages.label(seedMessages[i]),
        priority: _priorityFor(seedMessages[i]),
        status: AlertStatus.resolved,
        timestamp: DateTime.now().subtract(Duration(hours: i + 1)),
        acknowledgedAt: DateTime.now().subtract(Duration(hours: i + 1, minutes: -2)),
        acknowledgedBy: 'CMD-OPERATOR',
        latitude: soldier.latitude,
        longitude: soldier.longitude,
      );
      _alerts.add(alert);
      _history.add(HistoryEntry(
        id: 'HIS-${alert.id}',
        title: alert.messageLabel,
        description: '${alert.soldierCallsign} reported ${alert.messageLabel.toLowerCase()}',
        soldierCallsign: alert.soldierCallsign,
        timestamp: alert.timestamp,
        category: 'alert',
      ));
    }
  }

  AlertPriority _priorityFor(String code) {
    switch (code) {
      case TacticalMessages.soldierDown:
        return AlertPriority.critical;
      case TacticalMessages.needMedicalHelp:
        return AlertPriority.critical;
      case TacticalMessages.enemySpotted:
        return AlertPriority.high;
      case TacticalMessages.needBackup:
        return AlertPriority.high;
      case TacticalMessages.missionCompleted:
        return AlertPriority.low;
      default:
        return AlertPriority.medium;
    }
  }

  /// Starts the simulated telemetry heartbeat (battery drain, signal jitter,
  /// occasional randomized tactical messages). Call once after login.
  void startHeartbeat() {
    _heartbeatTimer?.cancel();
    _heartbeatTimer = Timer.periodic(AppConstants.heartbeatInterval, (_) {
      for (var i = 0; i < _soldiers.length; i++) {
        final s = _soldiers[i];
        if (s.status == SoldierStatus.offline) continue;
        final newBattery = (s.batteryLevel - _random.nextInt(2)).clamp(0, 100);
        final newSignal = (s.signalStrength + _random.nextInt(11) - 5).clamp(20, 100);
        _soldiers[i] = s.copyWith(
          batteryLevel: newBattery,
          signalStrength: newSignal,
          lastSeen: DateTime.now(),
          heartRate: 65 + _random.nextInt(40).toDouble(),
        );
      }
      _soldiersController.add(soldiers);
    });
  }

  void stopHeartbeat() {
    _heartbeatTimer?.cancel();
  }

  /// Simulates an RF packet arriving: a soldier transmits a tactical
  /// message which is decoded by the HT12D on the base station, relayed
  /// to the backend, and pushed to the app over WebSocket.
  AlertItem triggerMessage(String soldierId, String messageCode) {
    final soldier = _soldiers.firstWhere((s) => s.id == soldierId);
    final priority = _priorityFor(messageCode);
    final alert = AlertItem(
      id: 'ALT-${DateTime.now().millisecondsSinceEpoch}',
      soldierId: soldier.id,
      soldierCallsign: soldier.callsign,
      messageCode: messageCode,
      messageLabel: TacticalMessages.label(messageCode),
      priority: priority,
      status: AlertStatus.unacknowledged,
      timestamp: DateTime.now(),
      latitude: soldier.latitude,
      longitude: soldier.longitude,
    );
    _alerts.add(alert);
    _alertsController.add(alerts);

    final isEmergency = messageCode == TacticalMessages.soldierDown ||
        messageCode == TacticalMessages.needMedicalHelp;

    if (isEmergency) {
      final idx = _soldiers.indexWhere((s) => s.id == soldierId);
      _soldiers[idx] = soldier.copyWith(status: SoldierStatus.emergency, fallDetected: true);
      _soldiersController.add(soldiers);
      _emergencyController.add(alert);
    }

    final notif = NotificationItem(
      id: 'NTF-${DateTime.now().millisecondsSinceEpoch}',
      title: '${soldier.callsign}: ${alert.messageLabel}',
      body: 'Received at ${_formatTime(alert.timestamp)} · Priority: ${priority.label}',
      level: isEmergency
          ? NotificationLevel.critical
          : (priority == AlertPriority.high ? NotificationLevel.warning : NotificationLevel.info),
      timestamp: alert.timestamp,
      relatedAlertId: alert.id,
    );
    _notifications.insert(0, notif);
    _notificationsController.add(_notifications);

    _history.insert(
      0,
      HistoryEntry(
        id: 'HIS-${alert.id}',
        title: alert.messageLabel,
        description: '${soldier.callsign} reported ${alert.messageLabel.toLowerCase()}',
        soldierCallsign: soldier.callsign,
        timestamp: alert.timestamp,
        category: 'alert',
      ),
    );

    return alert;
  }

  void acknowledgeAlert(String alertId, String operator) {
    final idx = _alerts.indexWhere((a) => a.id == alertId);
    if (idx == -1) return;
    _alerts[idx] = _alerts[idx].copyWith(
      status: AlertStatus.acknowledged,
      acknowledgedAt: DateTime.now(),
      acknowledgedBy: operator,
    );
    _alertsController.add(alerts);

    final soldierId = _alerts[idx].soldierId;
    final sIdx = _soldiers.indexWhere((s) => s.id == soldierId);
    if (sIdx != -1 && _soldiers[sIdx].status == SoldierStatus.emergency) {
      _soldiers[sIdx] = _soldiers[sIdx].copyWith(status: SoldierStatus.active, fallDetected: false);
      _soldiersController.add(soldiers);
    }
  }

  void markNotificationRead(String id) {
    final idx = _notifications.indexWhere((n) => n.id == id);
    if (idx == -1) return;
    _notifications[idx] = _notifications[idx].copyWith(read: true);
    _notificationsController.add(_notifications);
  }

  void markAllNotificationsRead() {
    for (var i = 0; i < _notifications.length; i++) {
      _notifications[i] = _notifications[i].copyWith(read: true);
    }
    _notificationsController.add(_notifications);
  }

  String _formatTime(DateTime t) =>
      '${t.hour.toString().padLeft(2, '0')}:${t.minute.toString().padLeft(2, '0')}';

  void dispose() {
    _heartbeatTimer?.cancel();
    _soldiersController.close();
    _alertsController.close();
    _notificationsController.close();
    _emergencyController.close();
  }
}
