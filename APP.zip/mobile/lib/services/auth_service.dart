import 'package:dio/dio.dart';
import '../models/app_user.dart';
import '../models/enums.dart';
import 'api_client.dart';
import 'storage_service.dart';

class AuthException implements Exception {
  final String message;
  AuthException(this.message);
  @override
  String toString() => message;
}

/// Handles authentication against the backend `/auth` endpoints.
/// Falls back to a local demo account (commander/soldiershield123) when
/// the backend is unreachable, so the UI remains fully demoable while
/// the Node/Express backend is being stood up separately.
class AuthService {
  AuthService._internal();
  static final AuthService instance = AuthService._internal();

  static const _demoUsername = 'commander';
  static const _demoPassword = 'soldiershield123';

  Future<AppUser> login({
    required String username,
    required String password,
    required bool rememberMe,
  }) async {
    try {
      final response = await ApiClient.instance.dio.post('/auth/login', data: {
        'username': username,
        'password': password,
      });
      final data = response.data as Map<String, dynamic>;
      await StorageService.instance.saveTokens(
        access: data['accessToken'] as String,
        refresh: data['refreshToken'] as String,
      );
      await StorageService.instance.setRememberMe(rememberMe, username: username);
      return AppUser.fromJson(data['user'] as Map<String, dynamic>);
    } on DioException {
      // Backend not reachable yet -> allow demo login so the app remains usable.
      if (username == _demoUsername && password == _demoPassword) {
        await StorageService.instance.saveTokens(
          access: 'demo-access-token',
          refresh: 'demo-refresh-token',
        );
        await StorageService.instance.setRememberMe(rememberMe, username: username);
        return const AppUser(
          id: 'USR-0001',
          username: _demoUsername,
          fullName: 'Col. Aditya Sharma',
          role: UserRole.commander,
          department: 'Tactical Command Division',
        );
      }
      throw AuthException(
        'Unable to reach command server. Check connection or use demo credentials.',
      );
    }
  }

  Future<void> logout() async {
    try {
      await ApiClient.instance.dio.post('/auth/logout');
    } catch (_) {
      // Ignore network errors on logout - always clear local session.
    } finally {
      await StorageService.instance.clearTokens();
    }
  }

  Future<bool> get isLoggedIn async => (await StorageService.instance.accessToken) != null;
}
