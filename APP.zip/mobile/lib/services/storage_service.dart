import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:hive_flutter/hive_flutter.dart';
import '../core/constants/app_constants.dart';

/// Wraps secure storage (tokens) and Hive (app preferences/cache).
class StorageService {
  StorageService._internal();
  static final StorageService instance = StorageService._internal();

  final _secureStorage = const FlutterSecureStorage(
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  late Box _settingsBox;
  late Box _alertsCacheBox;

  Future<void> init() async {
    await Hive.initFlutter();
    _settingsBox = await Hive.openBox(AppConstants.boxSettings);
    _alertsCacheBox = await Hive.openBox(AppConstants.boxAlertsCache);
  }

  // ---- Secure token storage ----
  Future<void> saveTokens({required String access, required String refresh}) async {
    await _secureStorage.write(key: AppConstants.keyAccessToken, value: access);
    await _secureStorage.write(key: AppConstants.keyRefreshToken, value: refresh);
  }

  Future<String?> get accessToken => _secureStorage.read(key: AppConstants.keyAccessToken);
  Future<String?> get refreshToken => _secureStorage.read(key: AppConstants.keyRefreshToken);

  Future<void> clearTokens() async {
    await _secureStorage.delete(key: AppConstants.keyAccessToken);
    await _secureStorage.delete(key: AppConstants.keyRefreshToken);
  }

  // ---- Remember me ----
  Future<void> setRememberMe(bool value, {String? username}) async {
    await _settingsBox.put(AppConstants.keyRememberMe, value);
    if (username != null) {
      await _settingsBox.put(AppConstants.keySavedUsername, username);
    }
  }

  bool get rememberMe => _settingsBox.get(AppConstants.keyRememberMe, defaultValue: false);
  String? get savedUsername => _settingsBox.get(AppConstants.keySavedUsername);

  // ---- Generic settings ----
  T? getSetting<T>(String key, {T? defaultValue}) =>
      _settingsBox.get(key, defaultValue: defaultValue) as T?;

  Future<void> setSetting(String key, dynamic value) => _settingsBox.put(key, value);

  // ---- Alerts cache (offline support) ----
  Future<void> cacheAlerts(List<Map<String, dynamic>> alerts) async {
    await _alertsCacheBox.put('alerts', alerts);
  }

  List<Map<String, dynamic>> get cachedAlerts {
    final raw = _alertsCacheBox.get('alerts');
    if (raw == null) return [];
    return List<Map<String, dynamic>>.from(
      (raw as List).map((e) => Map<String, dynamic>.from(e)),
    );
  }
}
